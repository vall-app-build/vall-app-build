# Putra APK Builder

Starter project pribadi: upload `.html` atau `.zip`, build Android WebView APK di server, lalu upload APK ke akun MediaFire.

## Kebutuhan server
- Node.js 18+
- Java JDK 17
- Android SDK (platform 35 + build-tools) dan Gradle 8.9 tersedia di PATH
- Python 3.9+
- Akun MediaFire dan kredensial API MediaFire (application ID)

## Setup
1. Ekstrak ZIP ini di komputer/server.
2. Install Node dependencies:
   ```bash
   npm install
   ```
3. Install MediaFire SDK:
   ```bash
   python -m pip install mediafire
   ```
4. Salin `.env.example` menjadi `.env`, lalu isi `MEDIAFIRE_APP_ID`, `MEDIAFIRE_EMAIL`, dan `MEDIAFIRE_PASSWORD`. Opsional: `MEDIAFIRE_FOLDER_KEY`.
5. Pastikan `java -version`, `gradle -v`, dan Android SDK sudah berfungsi. Android SDK harus memiliki platform Android 35 dan build-tools yang sesuai.
6. Jalankan:
   ```bash
   npm start
   ```
7. Buka `http://localhost:3000`.

## Catatan penting
- Backend menjalankan `gradle :app:assembleDebug`; APK debug cocok untuk pengujian/pribadi. Untuk distribusi luas, buat konfigurasi signing release sendiri dan simpan keystore/password dengan aman.
- Kredensial MediaFire hanya boleh disimpan di `.env` pada server pribadi. Jangan masukkan ke HTML/JavaScript browser, jangan commit `.env`, dan jangan kirim password/API key ke orang lain.
- MediaFire API SDK pihak ketiga digunakan sebagai adapter. Periksa kompatibilitas SDK dan ketentuan MediaFire sebelum digunakan.
- Jangan mengekspos server build ke internet tanpa autentikasi, pembatasan ukuran, rate limit, dan isolasi proses. Starter ini ditujukan untuk penggunaan lokal/pribadi.
- Upload ZIP diekstrak setelah pemeriksaan path traversal dasar. Tetap hanya gunakan arsip yang dipercaya.
- APK dibuat menggunakan Android WebView. Situs yang membutuhkan backend/API eksternal tetap memerlukan koneksi internet.
