#!/usr/bin/env python3
"""Upload a built APK to MediaFire using the MediaFire Python Open SDK."""
import json, sys
from mediafire import MediaFireApi, MediaFireUploader

apk_path, app_id, email, password, folder_key = sys.argv[1:6]
api = MediaFireApi()
session = api.user_get_session_token(email=email, password=password, app_id=app_id)
api.session = session
uploader = MediaFireUploader(api)
with open(apk_path, "rb") as f:
    result = uploader.upload(f, apk_path.split("/")[-1], folder_key=folder_key or None)
info = api.file_get_links(result.quickkey)
links = info.get("links", [])
url = (links[0].get("normal_download") or links[0].get("direct_download") or
       f"https://www.mediafire.com/file/{result.quickkey}")
print(json.dumps({"url": url, "quickkey": result.quickkey}))
