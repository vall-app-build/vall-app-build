const express = require("express");
const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const TEMPLATE = path.join(ROOT, "android-template");
const TMP = path.join(os.tmpdir(), "putra-apk-builder");
fs.mkdirSync(TMP, { recursive: true });

const upload = multer({
  dest: path.join(TMP, "uploads"),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 50) * 1024 * 1024 }
});

app.use(express.static(path.join(ROOT, "public")));
app.use(express.json({ limit: "1mb" }));

function safeName(value, fallback) {
  const s = String(value || fallback).replace(/[^a-zA-Z0-9 _.-]/g, "").trim().slice(0, 40);
  return s || fallback;
}
function safePackage(value) {
  const p = String(value || "com.putra.myapp").toLowerCase();
  if (!/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*){1,5}$/.test(p)) {
    throw new Error("Package name tidak valid. Contoh: com.putra.aplikasi");
  }
  return p;
}
function copyDir(src, dst) {
  fs.mkdirSync(dst, { recursive: true });
  for (const item of fs.readdirSync(src, { withFileTypes: true })) {
    const a = path.join(src, item.name), b = path.join(dst, item.name);
    if (item.isDirectory()) copyDir(a, b);
    else fs.copyFileSync(a, b);
  }
}
function extractZipSafely(zipPath, target) {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();
  for (const entry of entries) {
    const name = entry.entryName.replace(/\\/g, "/");
    if (name.startsWith("/") || name.split("/").includes("..")) {
      throw new Error("ZIP berisi jalur file yang tidak aman.");
    }
  }
  zip.extractAllTo(target, true);
}
function findIndex(dir) {
  const direct = path.join(dir, "index.html");
  if (fs.existsSync(direct)) return dir;
  const children = fs.readdirSync(dir, { withFileTypes: true }).filter(x => x.isDirectory());
  if (children.length === 1) return findIndex(path.join(dir, children[0].name));
  return null;
}
function run(command, args, cwd) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env: process.env, shell: process.platform === "win32" });
    let output = "";
    child.stdout.on("data", d => output += d.toString());
    child.stderr.on("data", d => output += d.toString());
    child.on("error", reject);
    child.on("close", code => code === 0 ? resolve(output) : reject(new Error(output.slice(-5000) || `Build gagal (${code})`)));
  });
}
async function uploadMediaFire(apkPath) {
  const required = ["MEDIAFIRE_APP_ID", "MEDIAFIRE_EMAIL", "MEDIAFIRE_PASSWORD"];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) throw new Error("MediaFire belum dikonfigurasi di .env: " + missing.join(", "));
  const script = path.join(ROOT, "mediafire_upload.py");
  const args = [script, apkPath, process.env.MEDIAFIRE_APP_ID, process.env.MEDIAFIRE_EMAIL,
    process.env.MEDIAFIRE_PASSWORD, process.env.MEDIAFIRE_FOLDER_KEY || ""];
  const output = await run("python", args, ROOT);
  return JSON.parse(output.trim().split(/\r?\n/).slice(-1)[0]);
}

app.post("/api/build", upload.single("project"), async (req, res) => {
  let work;
  try {
    if (!req.file) return res.status(400).json({ error: "Pilih file HTML atau ZIP terlebih dahulu." });
    const original = req.file.originalname.toLowerCase();
    if (![".html", ".htm", ".zip"].some(ext => original.endsWith(ext))) {
      return res.status(400).json({ error: "Format harus .html, .htm, atau .zip." });
    }

    const appName = safeName(req.body.appName, "My HTML App");
    const packageName = safePackage(req.body.packageName);
    work = path.join(TMP, crypto.randomUUID());
    copyDir(TEMPLATE, work);
    const site = path.join(work, "app/src/main/assets/site");
    fs.mkdirSync(site, { recursive: true });

    if (original.endsWith(".zip")) {
      const extracted = path.join(work, "uploaded");
      fs.mkdirSync(extracted);
      extractZipSafely(req.file.path, extracted);
      const root = findIndex(extracted);
      if (!root) throw new Error("ZIP harus berisi index.html di folder utama (atau satu subfolder).");
      copyDir(root, site);
    } else {
      fs.copyFileSync(req.file.path, path.join(site, "index.html"));
    }

    const gradleFile = path.join(work, "app/build.gradle");
    let gradle = fs.readFileSync(gradleFile, "utf8");
    gradle = gradle.replace(/applicationId\s+"[^"]+"/, `applicationId "${packageName}"`)
                   .replace(/namespace\s+"[^"]+"/, `namespace "${packageName}"`);
    fs.writeFileSync(gradleFile, gradle);
    const strings = path.join(work, "app/src/main/res/values/strings.xml");
    fs.writeFileSync(strings, `<?xml version="1.0" encoding="utf-8"?>\n<resources><string name="app_name">${appName.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</string></resources>\n`);

    const gradleCmd = process.platform === "win32" ? "gradle.bat" : "gradle";
    await run(gradleCmd, [":app:assembleDebug", "--no-daemon"], work);
    const apk = path.join(work, "app/build/outputs/apk/debug/app-debug.apk");
    if (!fs.existsSync(apk)) throw new Error("Build selesai tetapi file APK tidak ditemukan.");

    const uploaded = await uploadMediaFire(apk);
    res.json({ ok: true, appName, apkName: `${appName.replace(/\s+/g, "-")}.apk`,
      mediafireUrl: uploaded.url, message: "APK berhasil dibuat dan diunggah ke MediaFire." });
  } catch (e) {
    res.status(500).json({ error: e.message || "Terjadi kesalahan saat build." });
  } finally {
    if (req.file && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
  }
});

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Putra APK Builder berjalan di http://localhost:${PORT}`));
